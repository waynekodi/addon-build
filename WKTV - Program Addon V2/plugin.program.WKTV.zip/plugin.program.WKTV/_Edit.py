import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/waynekodi/addon-build/master/WKTV%20-%20Program%20Addon%20V2/Example/home.txt'
addon = xbmcaddon.Addon('plugin.program.WKTV')